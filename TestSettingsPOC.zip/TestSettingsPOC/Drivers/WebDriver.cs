﻿using System;
using System.Configuration;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Edge;
using Microsoft.Extensions.Configuration;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Interfaces;
using OpenQA.Selenium.Appium.MultiTouch;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Appium.Android;

namespace WebShopTestAutomation.Drivers
{
    public class WebDriver
    {
        private IWebDriver _currentWebDriver;
        //private WebDriverWait _wait;
      
        public static bool isDesktop = true;
        public IWebDriver Current(out bool desktop)
        {
                desktop = true;
                if (_currentWebDriver == null)
                {
                   _currentWebDriver = GetWebDriver(out desktop);
                   isDesktop = desktop;
                }
                else
                {
                  desktop = isDesktop;
                }

                 return _currentWebDriver;
           
        }

        //public WebDriverWait Wait
        //{
        //    get
        //    {
        //        if (_wait == null)
        //        {
        //            this._wait = new WebDriverWait(Current, TimeSpan.FromSeconds(60));
        //        }
        //        return _wait;
        //    }
        //}

        private IWebDriver GetWebDriver(out bool desktop)
        {
            AppiumOptions app_options = new AppiumOptions();

            switch (Environment.GetEnvironmentVariable("Test_Browser"))
            {
                //case "Desktop_IE":
                //    var options = new InternetExplorerOptions();
                //    options.IgnoreZoomLevel = true;

                //    string DriversPath = @"..\WebDriversSetup\IEDriver";
                //    return new InternetExplorerDriver(DriversPath, options, TimeSpan.FromSeconds(120));


                //case "Desktop_Chrome":
                //    var chromeOptions = new ChromeOptions();

                //    return new ChromeDriver(@"..\WebDriversSetup\ChromeDriver");
                //case "Desktop_Firefox":
                //    var ffOptions = new FirefoxOptions();
                //    return new FirefoxDriver(@"..\WebDriversSetup\FirefoxDriver");

                //default: return new ChromeDriver(@"..\WebDriversSetup\ChromeDriver");

               

                case "Desktop_Chrome":
                    
                 
                    desktop = true;
                    return new ChromeDriver();
            
             


                default:
                    desktop = true;
                    return new ChromeDriver();



            }
        }

        public void Quit()
        {
            _currentWebDriver?.Quit();
        }
    }
}
