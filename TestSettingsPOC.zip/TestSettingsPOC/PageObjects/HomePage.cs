﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using WebShopTestAutomation.Drivers;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;

namespace WebShopTestAutomation.PageObjects
{
    public class HomePage
    {

        private WebDriverWait wait;
        //private readonly Actions actions;
        //private IJavaScriptExecutor js;
        WebDriver driver;
        bool desktop = true;
        public HomePage(WebDriver webDriver)
        {

            this.driver = webDriver;

            wait = new WebDriverWait(driver.Current(out desktop), TimeSpan.FromSeconds(120));

        }

        public IList<IWebElement> GetCookieButton()
        {
            IList<IWebElement> CookieButton = driver.Current(out desktop).FindElements(By.XPath("//button[contains(@class, 'cc_btn_accept_all')]"));
            return CookieButton;

        }
        public IWebElement GetBurgerMenu()
        {
            IWebElement BurgerMenu = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'site-header__user-content-mobile-burgermenu')]")));
            return BurgerMenu;

        }

        public IWebElement GetCloseMenu()
        {
            IWebElement CloseMenu = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'site-header__user-content-mobile-burgermenu-icon-on')]")));
            return CloseMenu;

        }


        public IWebElement GetLocationFilter()
        {
            IWebElement LocationFilter = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'search-form-field__input-inner-wrapper')]/input")));
            return LocationFilter;

        }

        public IWebElement GetDesinationClose()
        {
            IWebElement LocationFilter = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'search-form__destination-item-close')]")));
            return LocationFilter;

        }
        public List<IWebElement> SelectLocationFromList()
        {

          // wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//a[contains(@class, 'search-guide__item-selection')]")));
            List<IWebElement> SelectLocation = driver.Current(out desktop).FindElements(By.XPath("//a[contains(@class, 'search-guide__item-selection')]")).ToList(); 
            return SelectLocation;
        }

        public IList<IWebElement> SelectArrivalDate()
        {
            IWebElement ArrivalDate = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'CalendarMonth--horizontal')][@data-visible='true']//td[contains(@class, 'CalendarDay--valid')]/button[contains(@class, 'CalendarDay__button')]")));

            IList<IWebElement> lstArrivalDate = driver.Current(out desktop).FindElements(By.XPath("//div[contains(@class, 'CalendarMonth--horizontal')][@data-visible='true']//td[contains(@class, 'CalendarDay--valid')]/button[contains(@class, 'CalendarDay__button')]"));

            return lstArrivalDate;
        }

        public IWebElement GetHomePageSearchButton()
        {
            IWebElement SearchButton = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//button[contains(@class, 'frontpage-search__search-button')]")));
            return SearchButton;
        }

        public IWebElement GetSearchButton()
        {
            IWebElement SearchButton = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//button[contains(@class, 'search-form__search-button')]")));
            return SearchButton;
        }
             
        public IWebElement GetThemePageLink()
        {
            IWebElement SearchButton = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//nav[contains(@class, 'site-header__nav')]//li[contains(@class, 'themepicker')]//a")));
            return SearchButton;
        }

        public IWebElement GetCalenderRightArrow()
        {
            IWebElement ArrivalCalender = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'DayPickerNavigation')]//button[contains(@class, 'DayPickerNavigation__next')]")));
            return ArrivalCalender;
        }

    }
  }
