﻿using System;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Chrome;
using WebShopTestAutomation.Drivers;
using System.Configuration;
using System.Text.RegularExpressions;
//using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Drawing;
using WebShopTestAutomation.PageObjects;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.Configuration;
using OpenQA.Selenium.Interactions;
using System.Threading;
using NUnit.Framework;



namespace WebShopTestAutomation
{
    [Binding]
    
    public class CheckTheSearchFunctionalityToFindHolidayHomesSteps
    {
        private readonly WebDriver driver;
       
        public CheckTheSearchFunctionalityToFindHolidayHomesSteps(WebDriver webDriver)
        {
            driver = webDriver;
            //_bsDriver = (BrowserStackDriver)ScenarioContext.Current["bsDriver"];
        }

       
        public static bool desktop = true;
        protected string baseUrl = TestContext.Parameters["seleniumBaseUrl"];


        [Given(@"I am on Novasol website(.*)")]
        public void GivenIAmOnNovasolWebsite(string url)
        {
            var _driver = driver.Current(out desktop);

            try
            {
                url = Regex.Replace(url, @"\s", "");

                if(desktop)
                { 
                _driver.Manage().Window.Maximize();
                }


                var config = new ConfigurationBuilder().AddJsonFile("specflow.json").Build();

                //string baseUrl = config["seleniumBaseUrl"];

                _driver.Navigate().GoToUrl(string.Format("{0}{1}", baseUrl, url));
                _driver.Manage().Cookies.DeleteAllCookies();
                Cookie c = new Cookie("gtm_use_cdn", "TRUE");
                _driver.Manage().Cookies.AddCookie(c);
                driver.Quit();
            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;
            }
        }

    }
}
