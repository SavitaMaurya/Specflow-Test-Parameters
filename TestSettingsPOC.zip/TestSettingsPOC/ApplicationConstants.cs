﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebShopTestAutomation
{
    public class ApplicationConstants
    {
        //Sign up for booking details

        public static string firstName = "SavItal";
        public static string lastName = "Maurya";
        public static string email = "savItal.maurya@novasol.com";
        public static string phone = "1234567";
        public static string additionalPhone = "9876543";
        public static string address = "Nordre Fasanvey";
        public static string houseNumber = "129";
        public static string floor = "3rd";
        public static string additionalAddress = "Fredereiksberg";
        public static string postalCode = "2000";
        public static string city = "Copenhagen";
        public static string country = "D";

        //MasterCard Details

        public static string NameOnCard = "VISADANKORT";
        public static string CardNum = "5019 1000 0000 0000";
        public static string ExpMon = "06";
        public static string ExpYear = "2024";
        public static string Cvv = "684";


    }
}
